
uint apex_crc16(byte *param_1,long param_2)

{
  byte *pbVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  short sVar5;
  
  if (param_2 != 0) {
    pbVar1 = param_1 + param_2;
    uVar3 = 0xffffffff;
    do {
      uVar3 = uVar3 ^ (uint)*param_1 << 8;
      iVar4 = 8;
      do {
        uVar2 = uVar3 * 2;
        sVar5 = (short)uVar3;
        uVar3 = uVar2;
        if (sVar5 < 0) {
          uVar3 = uVar2 ^ 0x1021;
        }
        iVar4 = iVar4 + -1;
      } while (iVar4 != 0);
      param_1 = param_1 + 1;
    } while (pbVar1 != param_1);
    return uVar3;
  }
  return 0xffffffff;
}

