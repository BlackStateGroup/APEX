
void apex_stream_feed(byte *param_1,byte *param_2,long param_3)

{
  ulong uVar1;
  byte *pbVar2;
  uint uVar3;
  long lVar4;
  ushort uVar5;
  ushort uVar6;
  ushort uVar7;
  ulong uVar8;
  int iVar9;
  byte *pbVar10;
  undefined8 *puVar11;
  ulong uVar12;
  long in_FS_OFFSET;
  bool bVar13;
  byte bVar14;
  undefined1 auStack_250 [8];
  undefined2 local_248;
  undefined4 local_246;
  undefined1 local_242 [514];
  long local_40;
  
  bVar14 = 0;
  pbVar2 = param_2 + param_3;
  local_40 = *(long *)(in_FS_OFFSET + 0x28);
  if (param_3 == 0) {
LAB_0010181d:
    if (local_40 == *(long *)(in_FS_OFFSET + 0x28)) {
      return;
    }
                    /* WARNING: Subroutine does not return */
    auStack_250 = (undefined1  [8])&UNK_001018d6;
    __stack_chk_fail();
  }
  do {
    lVar4 = *(long *)(param_1 + 0x210);
    if (lVar4 == 0x20c) {
      auStack_250 = (undefined1  [8])0x101881;
      memmove(param_1,param_1 + 1,0x20b);
      *(long *)(param_1 + 0x218) = *(long *)(param_1 + 0x218) + 1;
      uVar12 = 0x20c;
      param_1[0x210] = 0xc;
      param_1[0x211] = 2;
      param_1[0x212] = 0;
      param_1[0x213] = 0;
      param_1[0x214] = 0;
      param_1[0x215] = 0;
      param_1[0x216] = 0;
      param_1[0x217] = 0;
      param_1[0x20b] = *param_2;
      goto LAB_001016d5;
    }
    uVar12 = lVar4 + 1;
    *(ulong *)(param_1 + 0x210) = uVar12;
    param_1[lVar4] = *param_2;
joined_r0x0010168a:
    if (1 < uVar12) {
LAB_001016d5:
      do {
        if ((*param_1 == 0x41) && (param_1[1] == 0x58)) {
          if (uVar12 < 10) break;
          uVar3 = *(uint *)(param_1 + 6);
          if ((((param_1[2] != 1) || (2 < (byte)(param_1[3] - 1))) || (param_1[5] != 0)) ||
             ((uVar5 = (ushort)(uVar3 >> 0x10), (short)uVar3 == 0 || (0x200 < uVar5))))
          goto LAB_00101698;
          uVar8 = (ulong)(uint)uVar5;
          uVar1 = uVar8 + 0xc;
          if (uVar12 < uVar1) break;
          uVar7 = 0xffff;
          pbVar10 = param_1;
          do {
            uVar7 = uVar7 ^ (ushort)*pbVar10 << 8;
            iVar9 = 8;
            do {
              uVar6 = uVar7 * 2;
              bVar13 = (short)uVar7 < 0;
              uVar7 = uVar6;
              if (bVar13) {
                uVar7 = uVar6 ^ 0x1021;
              }
              iVar9 = iVar9 + -1;
            } while (iVar9 != 0);
            pbVar10 = pbVar10 + 1;
          } while (pbVar10 != param_1 + uVar8 + 10);
          if (*(ushort *)(param_1 + uVar8 + 10) != uVar7) goto LAB_00101698;
          local_248 = *(undefined2 *)(param_1 + 3);
          local_246 = uVar3;
          if (uVar5 < 8) {
            if ((uVar3 & 0x40000) == 0) {
              if (uVar5 != 0) {
                local_242[0] = param_1[10];
                if ((uVar3 & 0x20000) != 0) {
                  *(undefined2 *)((long)&local_246 + uVar8 + 2) =
                       *(undefined2 *)(param_1 + uVar8 + 8);
                }
              }
            }
            else {
              local_242._0_4_ = *(undefined4 *)(param_1 + 10);
              *(undefined4 *)((long)&local_246 + uVar8) = *(undefined4 *)(param_1 + uVar8 + 6);
            }
          }
          else {
            local_242._0_8_ = *(undefined8 *)(param_1 + 10);
            *(undefined8 *)(auStack_250 + uVar8 + 6) = *(undefined8 *)(param_1 + uVar8 + 2);
            pbVar10 = param_1 + (10 - (long)(local_242 + -(long)(local_242 + 2)));
            puVar11 = (undefined8 *)(local_242 + 2);
            for (uVar8 = (ulong)((uint)uVar5 + (int)(local_242 + -(long)(local_242 + 2)) >> 3);
                uVar8 != 0; uVar8 = uVar8 - 1) {
              *puVar11 = *(undefined8 *)pbVar10;
              pbVar10 = pbVar10 + ((ulong)bVar14 * -2 + 1) * 8;
              puVar11 = puVar11 + (ulong)bVar14 * -2 + 1;
            }
          }
          auStack_250 = (undefined1  [8])0x1017cc;
          memmove(param_1,param_1 + uVar1,uVar12 - uVar1);
          uVar12 = *(long *)(param_1 + 0x210) - uVar1;
          *(ulong *)(param_1 + 0x210) = uVar12;
          if (*(code **)(param_1 + 0x220) != (code *)0x0) goto code_r0x001017ed;
        }
        else {
LAB_00101698:
          auStack_250 = (undefined1  [8])0x1016a7;
          memmove(param_1,param_1 + 1,uVar12 - 1);
          uVar12 = *(long *)(param_1 + 0x210) - 1;
          *(ulong *)(param_1 + 0x210) = uVar12;
          *(long *)(param_1 + 0x218) = *(long *)(param_1 + 0x218) + 1;
        }
        if (uVar12 < 2) break;
      } while( true );
    }
    param_2 = param_2 + 1;
    if (param_2 == pbVar2) goto LAB_0010181d;
  } while( true );
code_r0x001017ed:
  auStack_250 = (undefined1  [8])0x1017f9;
  (**(code **)(param_1 + 0x220))(&local_248,*(undefined8 *)(param_1 + 0x228));
  uVar12 = *(ulong *)(param_1 + 0x210);
  goto joined_r0x0010168a;
}

