
ulong apex_encode(byte *param_1,byte *param_2,ulong param_3)

{
  byte bVar1;
  ushort uVar2;
  ushort uVar3;
  void *pvVar4;
  int iVar5;
  ulong uVar6;
  byte *pbVar7;
  ulong uVar8;
  bool bVar9;
  
  if ((param_1 != (byte *)0x0) && (param_2 != (byte *)0x0)) {
    uVar6 = 0;
    if (((byte)(*param_1 - 1) < 3) &&
       ((*(short *)(param_1 + 2) != 0 &&
        (uVar8 = (ulong)*(ushort *)(param_1 + 4), *(ushort *)(param_1 + 4) < 0x201)))) {
      uVar6 = uVar8 + 0xc;
      if (param_3 < uVar6) {
        return 0;
      }
      param_2[2] = 1;
      param_2[0] = 0x41;
      param_2[1] = 0x58;
      param_2[3] = *param_1;
      bVar1 = param_1[1];
      param_2[5] = 0;
      param_2[4] = bVar1;
      *(undefined2 *)(param_2 + 6) = *(undefined2 *)(param_1 + 2);
      *(undefined2 *)(param_2 + 8) = *(undefined2 *)(param_1 + 4);
      pvVar4 = memcpy(param_2 + 10,param_1 + 6,(ulong)*(ushort *)(param_1 + 4));
      uVar3 = 0xffff;
      pbVar7 = param_2;
      do {
        uVar3 = uVar3 ^ (ushort)*pbVar7 << 8;
        iVar5 = 8;
        do {
          uVar2 = uVar3 * 2;
          bVar9 = (short)uVar3 < 0;
          uVar3 = uVar2;
          if (bVar9) {
            uVar3 = uVar2 ^ 0x1021;
          }
          iVar5 = iVar5 + -1;
        } while (iVar5 != 0);
        pbVar7 = pbVar7 + 1;
      } while (pbVar7 != (byte *)((long)pvVar4 + uVar8));
      *(ushort *)(param_2 + uVar8 + 10) = uVar3;
    }
    return uVar6;
  }
  return 0;
}

