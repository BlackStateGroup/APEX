
void apex_device_feed(void)

{
  apex_stream_feed();
  return;
}

