#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef unsigned char byte; typedef unsigned char uchar; typedef unsigned short ushort; typedef unsigned int uint; typedef unsigned long ulong; typedef unsigned long long ulonglong; typedef unsigned char undefined; typedef uint8_t undefined1; typedef uint16_t undefined2; typedef uint32_t undefined4; typedef uint64_t undefined8;

uint apex_crc16(byte *param_1,long param_2)

{
  byte *pbVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  short sVar5;
  
  if (param_2 != 0) {
    pbVar1 = param_1 + param_2;
    uVar3 = 0xffffffff;
    do {
      uVar3 = uVar3 ^ (uint)*param_1 << 8;
      iVar4 = 8;
      do {
        uVar2 = uVar3 * 2;
        sVar5 = (short)uVar3;
        uVar3 = uVar2;
        if (sVar5 < 0) {
          uVar3 = uVar2 ^ 0x8005;
        }
        iVar4 = iVar4 + -1;
      } while (iVar4 != 0);
      param_1 = param_1 + 1;
    } while (pbVar1 != param_1);
    return uVar3;
  }
  return 0xffffffff;
}


int main(void) { char line[1027]; unsigned char data[512]; while(fgets(line,sizeof(line),stdin)) { size_t n=strcspn(line,"\n"); if(n%2 || n>1024) return 2; for(size_t i=0;i<n/2;i++){char h[3]={line[2*i],line[2*i+1],0};data[i]=(unsigned char)strtoul(h,0,16);} printf("%04x\n",(unsigned)apex_crc16(data,n/2)&65535); } return 0; }
